/**
 * LearnHub API Client
 * Handles communication with the Flask backend
 */

const API_BASE = 'http://localhost:5000/api';

// ============= API Helper Functions =============

async function apiRequest(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include', // Include cookies for session
    };

    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, options);
        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || 'Request failed');
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// ============= Authentication API =============

const AuthAPI = {
    async register(name, email, password, phone = '') {
        const result = await apiRequest('/auth/register', 'POST', {
            name, email, password, phone
        });

        // Store user in localStorage for quick access
        if (result.user) {
            localStorage.setItem('currentUser', JSON.stringify(result.user));
        }

        return result;
    },

    async login(email, password) {
        const result = await apiRequest('/auth/login', 'POST', {
            email, password
        });

        if (result.user) {
            localStorage.setItem('currentUser', JSON.stringify(result.user));
        }

        return result;
    },

    async logout() {
        await apiRequest('/auth/logout', 'POST');
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    },

    async getCurrentUser() {
        try {
            const result = await apiRequest('/auth/me');
            return result.user;
        } catch {
            return null;
        }
    },

    async verifyEmail(code) {
        return await apiRequest('/auth/verify-email', 'POST', { code });
    }
};

// ============= User API =============

const UserAPI = {
    async getProfile() {
        const result = await apiRequest('/user/profile');
        return result.user;
    },

    async updateProfile(data) {
        const result = await apiRequest('/user/profile', 'PUT', data);

        if (result.user) {
            localStorage.setItem('currentUser', JSON.stringify(result.user));
        }

        return result;
    }
};

// ============= Progress API =============

const ProgressAPI = {
    async getProgress() {
        const result = await apiRequest('/progress');
        return result.progress;
    },

    async completeLesson(courseId, lessonId) {
        return await apiRequest('/progress/lesson', 'POST', {
            course_id: courseId,
            lesson_id: lessonId
        });
    },

    async completeExercise(exerciseId, score) {
        return await apiRequest('/progress/exercise', 'POST', {
            exercise_id: exerciseId,
            score
        });
    },

    async submitExam(examId, score) {
        return await apiRequest('/progress/exam', 'POST', {
            exam_id: examId,
            score
        });
    }
};

// ============= Dashboard API =============

const DashboardAPI = {
    async getData() {
        return await apiRequest('/dashboard');
    }
};

// ============= Courses API =============

const CoursesAPI = {
    async getAll() {
        const result = await apiRequest('/courses');
        return result.courses;
    },

    async getById(courseId) {
        const result = await apiRequest(`/courses/${courseId}`);
        return result.course;
    }
};

// ============= UI Helper Functions =============

function checkAuthAndUpdateUI() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    const authButtons = document.getElementById('authButtons');
    const userProfile = document.getElementById('userProfile');

    if (user && authButtons && userProfile) {
        authButtons.style.display = 'none';
        userProfile.style.display = 'flex';

        const userName = document.getElementById('userName');
        const userAvatar = document.getElementById('userAvatar');

        if (userName) userName.textContent = user.name;
        if (userAvatar) userAvatar.src = user.avatar || 'https://via.placeholder.com/40';
    }
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 2rem;
        border-radius: 8px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        font-weight: 500;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ============= Initialize on Page Load =============

document.addEventListener('DOMContentLoaded', () => {
    checkAuthAndUpdateUI();
});

// Export for use in other scripts
window.AuthAPI = AuthAPI;
window.UserAPI = UserAPI;
window.ProgressAPI = ProgressAPI;
window.DashboardAPI = DashboardAPI;
window.CoursesAPI = CoursesAPI;
window.showNotification = showNotification;
